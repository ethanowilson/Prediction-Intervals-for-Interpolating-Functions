function result = numerical_s(x, y, s, xx, method)

% Returns the approximate standard deviations of interpolated y-values when 
% observations may include measurement or rounding error. 
% Standard deviations are calculated using 10,000 Monte Carlo simulations 
% with the specified method.

% The vectors x and y give the x- and y-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 
% The vector xx gives the query points.
% The 'method' argument can be any interpolation method recognized by the 
% interp1 command: 'linear', 'nearest', 'next', 'previous', 'pchip', 
% 'cubic', 'v5cubic', 'makima', or 'spline'.

% Example input: 
% numerical_s([0,0.5,1], [0,1,0], 0.1, 0:.1:1, 'makima')

if max(xx) > max(x)
    error('Extrapolation is not supported.')
elseif min(xx) < min(x)
    error('Extrapolation is not supported.')
elseif length(x) ~= length(y)
    error('The number of x values must equal the number of y values')
end

n = length(x);

% Determine the width of the prediction interval using 10,000 Monte Carlo
% simulations.

con = ones(10000, length(xx));
for k = 1:10000
  y2 = y + normrnd(0, s, 1, n);
  con(k,:) = interp1(x,y2,xx, method);
end

result = std(con);