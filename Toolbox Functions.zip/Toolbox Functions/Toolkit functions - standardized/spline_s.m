function result = spline_s(x, s, xx)

% Returns the standard deviations of y-values interpolated using the
% piecewise linear method when observations may include measurement or 
% rounding error.

% The vector x gives the x-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 
% The vector xx gives the query points.

% Example input:
% spline_s(0:5, .2, 0:.1:5)

% For this interpolation method, the standard deviations of interpolated 
% values do not depend on the y-values of the nodes, only the x-values.



% The vectors a, b, c, d below should be interpreted as follows:
% S_j = a_j + b_j(x-x_j) + c_j(x-x_j)^2 + d_j(x-x_j)^3

% First compute A (notation per Burden-Faires)
n = length(x);
h = diff(x);
A = diag([1, 2*(h(1:(end-1)) + h(2:end)), 1]);

for k = 2:(n-1)
    A(k, k-1) = h(k-1);
    A(k, k+1) = h(k);
end

% Compute M_v:
M_v = zeros(n);
for k = 2:(n-1)
    M_v(k, k-1) = 3 / h(k-1);
    M_v(k, k) = -3 / h(k-1) - 3 / h(k);
    M_v(k, k+1) = 3 / h(k);
end

% M_d, M_ba, and M_bc:
M_d = zeros(n-1, n);
M_b = zeros(n-1, n);
for k = 1:(n-1)
    M_d(k, k) = -1 / h(k);
    M_d(k, k+1) = 1 / h(k);
    M_b(k, k) = (2/3) * h(k);
    M_b(k, k+1) = (1/3) * h(k);
end
M_d = (1/3) * M_d;


% Matrices for covariance calculations
a_mat = eye(n);
a_mat = a_mat(1:(n-1), :);
b_mat = 3 * M_d - M_b / A * M_v;
c_mat = A \ M_v;
c_mat = c_mat(1:(n-1),:);
d_mat = M_d / A * M_v;

% Calculate covariances, ignoring s for now
cov_ab = diag(a_mat * transpose(b_mat));
cov_ac = diag(a_mat * transpose(c_mat));
cov_ad = diag(a_mat * transpose(d_mat));
cov_bc = diag(b_mat * transpose(c_mat));
cov_bd = diag(b_mat * transpose(d_mat));
cov_cd = diag(c_mat * transpose(d_mat));
var_b = diag(b_mat * transpose(b_mat));
var_c = diag(c_mat * transpose(c_mat));
var_d = diag(d_mat * transpose(d_mat));

% For each query point xx, identify the node immediately prior.
node_index = zeros(length(xx),1);
for k = 1:length(xx)
    i = sum(x<=xx(k)); % index of node just before value xx(k)
    if i == length(x) % In case a value in xx is the right endpoint.
        node_index(k) = i - 1;
    else node_index(k) = i;
    end
end
node = x(node_index);

% Actually compute variances, finally. 
xx = transpose(xx);
node = transpose(node);
var_xx = 1 + (xx - node).^2 .* var_b(node_index) + (xx - node).^4 .* var_c(node_index) + (xx - node).^6 .* var_d(node_index) + 2*(xx - node) .* cov_ab(node_index)+ 2*(xx - node).^2 .* cov_ac(node_index) + 2*(xx - node).^3 .* cov_ad(node_index) + 2*(xx - node).^3 .* cov_bc(node_index) + 2*(xx - node).^4 .* cov_bd(node_index) + 2*(xx - node).^5 .* cov_cd(node_index);
result = transpose(s .* sqrt(var_xx));