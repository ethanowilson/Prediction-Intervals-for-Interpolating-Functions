function numerical_interval(x, y, s, method)

% Plots a 95% prediction band for an interpolant of the nodes (x, y) using
% the specified method.

% The vectors x and y give the x- and y-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 
% The 'method' argument can be any interpolation method recognized by the 
% interp1 command: 'linear', 'nearest', 'next', 'previous', 'pchip', 
% 'cubic', 'v5cubic', 'makima', or 'spline'.

% Example Input: 
% numerical_intervals([0,0.5,1], [0,1,0], 0.1, 'makima')

close
if length(x) ~= length(y)
    error('the number of x values must equal the number of y values')
end

n = length(x);
t = linspace(min(x), max(x), 100);
p = interp1(x, y, t, method);

% Determine the width of the prediction interval
s = numerical_s(x, y, s, t, method);

% Generate a plot of the result
plot(t, p, 'b', t, p + 1.96 * s, '--k', t, p - 1.96 * s, '--k', x, y, '.k');
legend({'Interpolant', '95% confidence'}, 'Location', 'southwest');

