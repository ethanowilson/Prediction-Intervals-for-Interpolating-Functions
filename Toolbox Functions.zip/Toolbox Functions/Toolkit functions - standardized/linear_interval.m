function linear_interval(x, y, s)

% Plots a 95% prediction band for a piecewise-linear interpolant of the
% nodes (x, y).

% The vectors x and y give the x- and y-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 

% Example Input: 
% linear_interval([0,0.5,1], [0,1,0], 0.1)

close
if length(x) ~= length(y)
    error('the number of x values must equal the number of y values')
end

n = length(x);
t = linspace(min(x), max(x), 1000);
p = interp1(x, y, t, 'linear');

% Determine the width of the prediction interval
s = linear_s(x, s, t);

% Generate a plot of the result
plot(t, p, 'b', t, p + 1.96 * s, '--k', t, p - 1.96 * s, '--k', x, y, '.k');
legend({'Interpolant', '95% confidence'}, 'Location', 'southwest');
