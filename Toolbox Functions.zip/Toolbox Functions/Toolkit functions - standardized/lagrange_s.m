function result = lagrange_s(x, s, xx)

% Returns the standard deviations of y-values interpolated using the
% Lagrange polynomial method when observations may include measurement or 
% rounding error.

% The vector x gives the x-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 
% The vector xx gives the query points.

% Example input:
% lagrange_s(0:5, .2, 0:.1:5)

% For this interpolation method, the standard deviations of interpolated 
% values do not depend on the y-values of the nodes, only the x-values.

if max(xx) > max(x)
    error('Extrapolation is not supported.')
elseif min(xx) < min(x)
    error('Extrapolation is not supported.')
end

    function out = lagrange(x, i, t)
        % For a vector of nodes x and output value t, returns the value of the
        % lagrange polynomial L_i,n(t) at t. 
        out = 1;
        for j = 1:length(x)
            if j ~= i
                out = out .* (t-x(j)) ./ (x(i) - x(j));
            end
        end
    end


result = zeros(1, length(xx));
for i = 1:length(x)
    result = result + (lagrange(x, i, xx)).^2;
end
result = s * sqrt(result);
end