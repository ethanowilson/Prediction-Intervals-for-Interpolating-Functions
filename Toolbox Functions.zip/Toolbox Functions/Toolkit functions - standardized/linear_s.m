function result = linear_s(x, s, xx)

% Returns the standard deviations of y-values interpolated using the
% piecewise linear method when observations may include measurement or 
% rounding error.

% The vector x gives the x-values of the nodes of interpolation.
% The scaler s gives the standard deviation of observations at any x. 
% The vector xx gives the query points.

% Example input:
% linear_s(0:5, .2, 0:.1:5)

% For this interpolation method, the standard deviations of interpolated 
% values do not depend on the y-values of the nodes, only the x-values.

if max(xx) > max(x)
    error('Extrapolation is not supported.')
elseif min(xx) < min(x)
    error('Extrapolation is not supported.')
end
    
% For each xx, identify the node immediately prior.
node_index = zeros(length(xx),1);
for k = 1:length(xx)
    i = sum(x<=xx(k)); % index of node just before value xx(k)
    if i == length(x) % In case a value in xx is the right endpoint.
        node_index(k) = i - 1;
    else node_index(k) = i;
    end
end

result = s.*sqrt(((xx-x(node_index)).^2 + (xx-x(node_index+1)).^2)/((x(2)-x(1)).^2));


